<?php
/*
 * ==> HOW TO CUSTOMIZE TEXT
 *
 * Follow this guide:
 * http://www.hesk.com/knowledgebase/?article=88
 *
 * ==> IMPORTANT: FILE ENCODING
 *
 * This file *must* be saved in UTF-8 encoding without byte order mark (BOM)
 * Test chars: àáâãäåæ
 *
 * http://www.hesk.com/knowledgebase/?article=87
 *
 */

// ADD AND MODIFY TEXT BELOW THIS LINE

// 1. Modificato il termine UTENTE (di Staff) in OPERATORE (di Staff) (HESK)

// ERROR MESSAGES
$hesklang['no_valid_id']='Codice operatore non valido';
$hesklang['user_not_found']='Operatore non trovato';
$hesklang['enter_real_name']='Inserire il nome reale dell\'operatore';
$hesklang['asign_one_cat']='Assegnare l\'operatore ad almeno una categoria!';
$hesklang['user_not_found_nothing_edit']='Operatore non trovato o nulla da modificare';

// ADMIN PANEL
$hesklang['user']='Operatore';
//$hesklang['cat_intro']='Qui è possibile gestire le categorie. Le categorie servono per differenziare i ticket per rilevanza (per esempio &quot;Vendite&quot;, &quot;Problemi hardware&quot;,&quot;Problemi di PHP/MySQL&quot; ecc…) e per assegnare gli operatori alle categorie (per esempio la persona che si occupa di vendite può vedere solo i ticket inviati alle categorie &quot;Vendite&quot;)';
$hesklang['sure_remove_user']='Si è sicuri di voler rimuovere questo operatore?';
$hesklang['manage_users']='Gestione operatori';
$hesklang['users_intro']='Qui è possibile gestire gli operatori che accedono al Pannello di Amministrazione e rispondono ai ticket. Gli amministratori possono invece visualizzare/modificare i ticket di qualsiasi categoria e hanno accesso a tutte le funzioni del Pannello di Amministrazione (gestione operatori, gestione categorie, ecc…), mentre gli altri operatori dello staff possono solo visualizzare e rispondere ai ticket delle loro categorie.';
$hesklang['add_user']='Aggiungi un nuovo operatore';
$hesklang['create_user']='Crea operatore';
$hesklang['editing_user']='Modifica operatore';
$hesklang['user_added']='Operatore aggiunto';
$hesklang['user_added_success']='Il nuovo operatore %s avente password %s è stato aggiunto con successo';
$hesklang['user_removed']='Operatore rimosso';
$hesklang['sel_user_removed']='L\'operatore selezionato è stato rimosso con successo dal database';
$hesklang['user_profile_updated_success']='Il profilo di questo operatore è stato aggiornato con successo';

// ADDED OR CHANGED IN VERSION 2.0
$hesklang['menu_users']='Operatori';
$hesklang['can_man_users']='Gestione operatori';
$hesklang['dan']='gli operatori possono eliminare le note solo dai propri ticket. Selezionare solo se si vuol consentire a questo operatore di eliminare anche le note di altri operatori';
$hesklang['asign_one_feat']='Assegna a questo utente almeno una autorizzazione!';
$hesklang['rated']='Valutazione operatore: %s/5.0 (%s voti)';
$hesklang['not_rated']='Operatore non ancora valutato';

// Added or modified in version 2.2
$hesklang['unoa']='L\'operatore selezionato non ha accesso a questa categoria';
$hesklang['taso']='Questo ticket è stato assegnato all\'operatore selezionato';
$hesklang['t3']='Ticket per operatore';
$hesklang['e_udel']='(Operatore eliminato)';

// Added or modified in version 2.3
$hesklang['uaaon']='L\'auto-assegnazione è stata abilitata per l\'operatore selezionato';
$hesklang['uaaoff']='L\'auto-assegnazione è stata disabilitata per l\'operatore selezionato';
$hesklang['onlinep']='Operatori online'; // For display
$hesklang['sonline']='Operatori online'; // For settings page
$hesklang['sonline2']='Mostra gli operatori present online. Limite (in minuti):'; // For settings page

// Added or modified in version 2.3
$hesklang['user_aa']='Assegna in automatico i ticket a questo operatore';
$hesklang['npea']='Non si dispone dei permessi per modificare questo operatore';
$hesklang['duplicate_user']='Esiste già un operatoree con questo nome utente. Scegliere un nome utente diverso';

// Added or modified in version 2.6.0
$hesklang['passa']='Gli operatori possono reimpostare la propria password dimenticata usando l\'indirizzo di email';

// Added or modified in version 2.6.0
$hesklang['imap_warning']='L\'operatore %1$s ha lo stesso indirizzo email del vostro indirizzo di email IMAP fetching: %2$s'; // %1$s = username, %2$s = email address
$hesklang['pop3_warning']='L\'operatore %1$s ha lo stesso indirizzo email del vostro indirizzo di email POP3 fetching: %2$s'; // %1$s = username, %2$s = email address
$hesklang['fetch_warning']='Ciò potrebbe determinare l\'insorgenza di un Email Loop in cui vengono creati nuovi ticket a partire dalle notifiche email dell\'operatore. L\'indirizzo di posta elettronica di fetching dovrebbe essere univoco e non essere usato da nessun altro';


// 2. Modificato il termine UTENTE (di Staff) in OPERATORE (di Staff) (Mods for HESK)
//$hesklang['disable_user']='Operatore attivo (fare clic per disattivarlo)';
//$hesklang['enable_user']='Opareatore disattivo (fare clic per attivarlo)';
//$hesklang['user_activated']='L\'operatore è stato attivato';
//$hesklang['user_deactivated']='L\'operatore è stato disattivato';
//$hesklang['active_user']='Operatore attivo';
//$hesklang['show_number_merged_help']='Se attivato, l\'operatore potrà vedere quali ticket sono stati uniti tra loro nella schermata di ricerca ticket';
//$hesklang['number_of_users']='Numero di operatori';
//$hesklang['sort_by_user_defined_order']='Definito dall\'operatore';
//$hesklang['category_sort_help']='Determina se le categorie visualizzate nella pagina di \'Gestione categorie\' e se tutte le liste a discesa verranno ordinate in base ad un ordinamento alfabetico o definito dall\'operatore (modalità predefinita).';
//$hesklang['status_sort_help']='Determina se gli stati visualizzati nella pagina \'Gestione stati\' e le relative liste a discesa verranno ordinati alfabeticamente o in base ad un ordinamento definito dall\'operatore (modalità predefinita).';
//$hesklang['deleted_user_title_case']='Operatore eliminato';
//$hesklang['user_security']='Sicurezza operatore';
//$hesklang['all_tokens_revoked']='Sono stati revocati tutti i token di questo operatore';
//$hesklang['url_help']='URL verso cui l\'operatore dovrebbe dirigersi. Sono ammesse sia URL assolute, sia URL relative';
//$hesklang['manage_permission_groups_help'] = 'Qui si possono creare e modificare i gruppi di autorizzazioni. I gruppi di autorizzazioni disponibili appaiono quando si crea/modifica un operatore. Quando si modificano le autorizzazioni associate ad un certo gruppo, tutti gli operatori che sono stati assegnati a tale gruppo avranno le loro autorizzazioni aggiornate di conseguenza.';
//$hesklang['changing_permissions_will_reset_permission_group'] = 'La modifica delle categorie/funzioni dell\'operatore azzera i relativi gruppi di autorizzazioni! Fare clic su "Abbandona modifiche" per azzerare le categorie/funzioni dell\'operatore.';

// DO NOT CHANGE BELOW
if (!defined('IN_SCRIPT')) die('PHP syntax OK!');